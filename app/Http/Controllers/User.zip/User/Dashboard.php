<?php


namespace App\Http\Controllers\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Dashboard extends Controller{

	public function store() {

		$user_id = session()->get('login');
		if($user_id) {
			$users = DB::table('users')->where('id', '=', $user_id )->get();
			return view('user.dashboard.home', ['users' => $users->first()]);
		}

		return view('signup');
	}
	
	public function test() {
		$user_id = session()->get('login');
		if($user_id) {
			$users = DB::table('users')->where('id', '=', $user_id )->get();
			return view('user.dashboard.tests', ['users' => $users->first()]);
		}

	}
	
	
	public function start_test() {


		$user_id = session()->get('login');
		if($user_id) {
			$users = DB::table('users')->where('id', '=', $user_id )->get();
			$end_test = $users->first()->end_test;

			if(empty($end_test)) {
				DB::table('users')->where('id', $user_id)->update(['start_test' => date('m/d/Y h:i:s a'), 'level_test' => 'A1.1', ]);
			};
			
			
/*
			$conn = mysqli_connect('localhost', 'mathexpe_alex', '16851750g', 'mathexpe_tests');
			$result = mysqli_query($conn, "select * from mat_a1_1");
			
			$tests = (mysqli_fetch_array($result));

			
			//DB::connection('mysql2')->select(...);
			//print_r( 'qwe' );
			//return (1);
			//return view('user.dashboard.tests');
			
			
			*/
			if(empty($users->first()->end_test)) {
				
				/*
$timenow = strtotime(date('Y-m-d H:i'));
				DB::table('users')->where('id', $user_id)->update(['end_test' => $timenow, 'level_test' => 'A1.1', ]);
				$allow_tests = true;
*/
			} 
			
/*
			elseif (($users->first()->end_test - strtotime(date('Y-m-d H:i')) ) {
			
				$timenow = strtotime(date('Y-m-d H:i'));
					
	
				echo strtotime( date("Y-m-d H:i", strtotime('+5 hours')) );
				
				print_r(($timenow - $users->first()->end_test) >= strtotime(date("Y-m-d H:i", strtotime('+5 hours'))));
				
				echo 'time : ' . $timenow . '<br />';
				echo 'MY test : ' . $timestamp;
			}
*/


			
			
		}
		return view('user.dashboard.start-tests', ['users' => $users->first(), 'allow_tests' => $allow_tests, ]);
		
	
	}

}